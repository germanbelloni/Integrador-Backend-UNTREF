use trailerflix;
INSERT INTO Categorias (id_categoria, nombre_categoria) VALUES (1, 'Serie');
INSERT INTO Categorias (id_categoria, nombre_categoria) VALUES (2, 'Película');